function set() {
    document.getElementById("online").innerHTML = "typing...";
}

function show() {
    document.getElementById("online").innerHTML = "online";
    var txt = document.getElementById("text1").value;

    document.getElementById("side").style.left = "240px";
    document.getElementById("img11").style.display = "none";
    document.getElementById("img12").style.display = "block";


    if (txt == "") {

        document.getElementById("side").style.left = "206px";
        document.getElementById("img11").style.display = "block";
        document.getElementById("img12").style.display = "none";
    }
}

function get() {
    var txt1 = document.getElementById("text1").value;
    var c = txt1.charAt(0)
    if (c == " ") {

        document.getElementById("text1").focus();

    } else {


        document.getElementById("msg").style.display = "block";
        document.getElementById("msg").innerHTML = txt1;
        document.getElementById("text1").value = "";
    }
}